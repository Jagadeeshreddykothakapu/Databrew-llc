import React from 'react';
import BannerSection from './BannerSection';


import TimeSheet from './TimeSheet';

export default function Index() {
  return (
    <>
      <BannerSection />
      
      <TimeSheet/>
      
    </>
  )
}