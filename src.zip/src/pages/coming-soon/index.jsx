import React from 'react';

export default function index() {
  return (
    <section className="pt-28 pb-20">
      <div className="container max-w-6xl mx-auto px-2">
        <h2 className='text-blue font-bold font-poppins text-5xl text-center'>Updating Soon!</h2>
      </div>
    </section>
  )
}
